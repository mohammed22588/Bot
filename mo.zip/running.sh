echo "Did you setup your Server and run script or run script only? [y/n]";
read status

if [ $status == "y" ]
then
apt update -y
apt upgrade -y
apt install python3 -y
apt install python3-pip -y
apt install screen -y
pip3 install telethon
pip3 install pyrogram
pip3 install requests
fi

screen_name="Jello"
rm *.session; screen -dmS "_signer" bash -c "python3 signerAccounts.py; exec bash";screen -dmS "_move" bash -c "python3 center.py; exec bash"
echo
echo "Done successfully ✓"
echo